package pt.projeto.iot.consistency;

public interface TxManager {
}
