package pt.projeto.iot.pipeline;

public interface Source {
}
