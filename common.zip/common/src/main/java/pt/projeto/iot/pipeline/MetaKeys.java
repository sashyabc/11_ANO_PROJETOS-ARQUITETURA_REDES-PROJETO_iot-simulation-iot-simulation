package pt.projeto.iot.pipeline;

public final class MetaKeys {
}
