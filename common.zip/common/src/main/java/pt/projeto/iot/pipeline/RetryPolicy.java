package pt.projeto.iot.pipeline;

public interface RetryPolicy {
}
