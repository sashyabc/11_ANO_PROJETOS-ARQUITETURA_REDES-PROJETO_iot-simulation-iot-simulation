package pt.projeto.iot.consistency;

public interface SagaCoordinator {
}
