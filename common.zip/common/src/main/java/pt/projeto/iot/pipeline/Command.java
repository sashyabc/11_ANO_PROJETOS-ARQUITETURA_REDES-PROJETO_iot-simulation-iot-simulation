package pt.projeto.iot.pipeline;

public record Command() {
}
