package pt.projeto.iot.pipeline;

public record CommandTarget() {
}
