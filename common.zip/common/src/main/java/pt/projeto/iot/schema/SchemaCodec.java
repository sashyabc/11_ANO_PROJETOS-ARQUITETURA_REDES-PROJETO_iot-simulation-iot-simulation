package pt.projeto.iot.schema;

public interface SchemaCodec {
}
