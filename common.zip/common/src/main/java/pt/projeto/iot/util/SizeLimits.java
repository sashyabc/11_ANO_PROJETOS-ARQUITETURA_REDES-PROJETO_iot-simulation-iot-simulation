package pt.projeto.iot.util;

public final class SizeLimits {
}
