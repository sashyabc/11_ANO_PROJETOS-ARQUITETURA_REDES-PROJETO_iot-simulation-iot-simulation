package pt.projeto.iot.pipeline;

public enum Unit {
}
