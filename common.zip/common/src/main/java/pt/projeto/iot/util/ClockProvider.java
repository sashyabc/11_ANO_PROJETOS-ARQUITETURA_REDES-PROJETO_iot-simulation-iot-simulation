package pt.projeto.iot.util;

public interface ClockProvider {
}
