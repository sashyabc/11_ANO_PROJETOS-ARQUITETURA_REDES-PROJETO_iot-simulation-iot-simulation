package pt.projeto.iot.pipeline;

public enum StreamType {
}
