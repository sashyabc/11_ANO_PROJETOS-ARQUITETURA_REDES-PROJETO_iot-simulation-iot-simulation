package pt.projeto.iot.observability;

public interface Tracer {
}
