package pt.projeto.iot.core;

public enum ErrorCategory {
}
