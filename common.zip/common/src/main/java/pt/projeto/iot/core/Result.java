package pt.projeto.iot.core;

public record Result() {
}
