package pt.projeto.iot.validation;

public interface Validator {
}
