package pt.projeto.iot.distribution;

public interface ShardAssigner {
}
