package pt.projeto.iot;

public interface Device {
    String getId();
    void start();
    void stop();
}