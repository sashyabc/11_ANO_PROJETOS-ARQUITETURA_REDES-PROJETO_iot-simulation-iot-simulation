package pt.projeto.iot.security;

public interface Authorizer {
}
