package pt.projeto.iot.security;

public record AuthResult() {
}
