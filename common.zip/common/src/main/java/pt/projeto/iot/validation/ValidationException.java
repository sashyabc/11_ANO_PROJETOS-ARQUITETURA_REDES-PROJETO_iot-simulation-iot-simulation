package pt.projeto.iot.validation;

public final class ValidationException {
}
