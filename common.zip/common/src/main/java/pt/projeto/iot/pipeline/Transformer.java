package pt.projeto.iot.pipeline;

public interface Transformer {
}
