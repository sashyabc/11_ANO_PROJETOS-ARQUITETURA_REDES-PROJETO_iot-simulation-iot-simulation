package pt.projeto.iot.distribution;

public interface LeaseManager {
}
