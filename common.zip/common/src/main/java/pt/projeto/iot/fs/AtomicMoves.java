package pt.projeto.iot.fs;

public final class AtomicMoves {
}
